<template>
  <div>
    <h1>{{ propsdata }}</h1>
  </div>
</template>

<script>
export default {
  props: ["propsdata"]
}
</script>

<style>

</style>
