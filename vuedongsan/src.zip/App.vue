<template>
  <div id="app">
    <div class="black-bg">
      <div class="white-bg">
        <h4>상세페이지임</h4>
        <p>상세페이지 내용임</p>
      </div>
    </div>

    <div class="menu">
      <a v-for="menu in menus" :key="menu" href="">{{ menu }}</a>
    </div>

    <div>
      <img src="./assets/room0.jpg" alt="" class="room-img">
      <h4>{{ products[0] }}</h4>
      <p>50 만원</p>
      <button @click="reportCount[0]++">허위매물신고</button> <span>신고수 : {{ reportCount[0] }}</span>
    </div>
    <div>
      <img src="./assets/room1.jpg" alt="" class="room-img">
      <h4>{{ products[1] }}</h4>
      <p>60 만원</p>
      <button @click="reportCount[1]++">허위매물신고</button> <span>신고수 : {{ reportCount[1] }}</span>
    </div>
    <div>
      <img src="./assets/room2.jpg" alt="" class="room-img">
      <h4>{{ products[2] }}</h4>
      <p>70 만원</p>
      <button @click="reportCount[2]++">허위매물신고</button> <span>신고수 : {{ reportCount[2] }}</span>
    </div>

    <!-- <div v-for="(item, index) in products" v-bind:key="item">
      <h4>{{ item }}</h4>
      <p>{{ prices[index] }}</p>
    </div> -->
  </div>
</template>

<script>

export default {
  name: 'App',
  data(){
    return {
      reportCount: [0, 0, 0],
      //reportCount: 0,
      prices: ['50만원', '60만원', '70만원'],
      menus: ['Home', 'Shop', 'About'],
      products: ['역삼동원룸', '천호동원룸', '마포구원룸'],
    }
  },
  /*methods: {
    increase(){
      this.reportCount++;
    },
  },*/
  components: {
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

.menu {
  background: darkslateblue;
  padding: 15px;
  border-radius: 5px;
}

.menu a {
  color: white;
  padding: 10px;
}

.room-img {max-width: 100%; margin-top: 40px;}

.black-bg {
  width: 100%; height: 100%;
  background: rgba(0,0,0,0.5);
}
</style>
