<template>
  <header>
    <h1>{{ propsdata }}</h1>
  </header>
</template>

<script>
export default {
  props: ["propsdata"],
}
</script>

<style>

</style>
